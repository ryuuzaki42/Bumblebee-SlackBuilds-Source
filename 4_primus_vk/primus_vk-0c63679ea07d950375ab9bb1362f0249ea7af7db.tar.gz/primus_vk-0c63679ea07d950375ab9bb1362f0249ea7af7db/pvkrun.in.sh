#!/bin/sh
ENABLE_PRIMUS_LAYER=1 exec primusrun "$@"
