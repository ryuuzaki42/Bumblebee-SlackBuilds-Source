
      FORWARD(GetPhysicalDeviceSurfaceCapabilitiesKHR);
    
      FORWARD(GetPhysicalDeviceSurfaceFormatsKHR);
    
      FORWARD(GetPhysicalDeviceSurfacePresentModesKHR);
    
      FORWARD(GetPhysicalDeviceSurfaceCapabilities2EXT);
    
      FORWARD(GetPhysicalDevicePresentRectanglesKHR);
    
      FORWARD(GetPhysicalDeviceSurfaceCapabilities2KHR);
    
      FORWARD(GetPhysicalDeviceSurfaceFormats2KHR);
    
