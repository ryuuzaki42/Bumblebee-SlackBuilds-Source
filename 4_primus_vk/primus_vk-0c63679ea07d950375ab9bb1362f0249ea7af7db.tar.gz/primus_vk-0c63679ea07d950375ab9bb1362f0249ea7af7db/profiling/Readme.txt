place the profiling output in a file named "trace.txt" in this directory.
Start a webserver here (e.g. python3 -m http.server)
Open the webpage.
